package com.ruru.practice.feature.practice

import com.ruru.practice.core.ui.CollapsibleNote

import com.ruru.practice.core.util.NotificationPermission

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.provider.OpenableColumns
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun WalkingScreen(
    viewModel: WalkingViewModel = hiltViewModel(),
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var selectedIds by remember { mutableStateOf(setOf<Long>()) }
    var confirmDelete by remember { mutableStateOf(false) }
    var showNotificationPermissionDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var bellName by remember { mutableStateOf(viewModel.bellSoundName()) }
    var bellError by remember { mutableStateOf<String?>(null) }
    val bellPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            val name = runCatching { context.contentResolver.query(it, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } }.getOrNull()
            viewModel.setBellSound(it, name).fold(
                onSuccess = {
                    val previewed = viewModel.previewBell()
                    bellName = viewModel.bellSoundName()
                    bellError = if (previewed) {
                        null
                    } else {
                        "音频已保存，但试听失败，请检查系统音量或重新选择。"
                    }
                },
                onFailure = { error ->
                    bellError = error.message ?: "本地音频保存失败，请重试。"
                }
            )
        }
    }
    Surface(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("经行", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("身体行走时，知道身体行走。经行本身就是正式修习。", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                Card {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("选择方法", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("全身行走", "脚步所缘").forEach { method ->
                                FilterChip(state.method == method, { viewModel.method(method) }, label = { Text(method) })
                            }
                        }
                        Text("60分钟倒计时", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("剩余 ${state.remaining / 60}分 ${state.remaining % 60}秒 · 已经行 ${state.elapsed / 60}分 ${state.elapsed % 60}秒")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            when (state.phase) {
                                WalkingTimerPhase.READY -> Button(onClick = {
                                    if (!NotificationPermission.isGranted(context)) showNotificationPermissionDialog = true
                                    else viewModel.start()
                                }) { Text("开始") }
                                WalkingTimerPhase.RUNNING -> Button(onClick = viewModel::pause) { Text("暂停") }
                                WalkingTimerPhase.PAUSED -> Button(onClick = viewModel::resume) { Text("继续") }
                                WalkingTimerPhase.FINISHED -> OutlinedButton(onClick = {
                                    if (!NotificationPermission.isGranted(context)) showNotificationPermissionDialog = true
                                    else viewModel.start()
                                }) { Text("重新开始") }
                            }
                            if (state.phase == WalkingTimerPhase.RUNNING || state.phase == WalkingTimerPhase.PAUSED) OutlinedButton(onClick = viewModel::finish) { Text("停止") }
                        }
                        Text("计时与当前页面无关：切换页面或暂时离开后仍会继续；进程被系统回收后也会按已练习时长恢复。", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Text("自然结束（满60分钟）时播放三次引磬；暂停、手动停止和离开页面不会误响。", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Text("结束震动与安般念共用开关（默认开启，模式：嗡～静～嗡～静～嗡）。", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Text("提示音与安般念同步：$bellName", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val previewed = viewModel.previewBell()
                                bellName = viewModel.bellSoundName()
                                bellError = if (previewed) {
                                    null
                                } else {
                                    "当前提示音无法播放，请重新选择音频或恢复默认。"
                                }
                            }) { Text("试听") }
                            OutlinedButton(onClick = { bellPicker.launch(arrayOf("audio/*")) }) { Text("选择本地音频") }
                            if (bellName != "软件内置引磬") TextButton(onClick = {
                                viewModel.useDefaultBellSound().fold(
                                    onSuccess = {
                                        bellName = viewModel.bellSoundName()
                                        bellError = null
                                    },
                                    onFailure = { error ->
                                        bellError = error.message ?: "恢复默认提示音失败，请重试。"
                                    }
                                )
                            }) { Text("恢复默认") }
                        }
                        bellError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                        OutlinedTextField(
                            state.note,
                            viewModel::note,
                            label = { Text("经行后的观察") },
                            placeholder = { Text("散乱、昏沉、焦躁、身体感受、无常变化……") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(onClick = viewModel::save, enabled = state.elapsed > 0 && state.phase != WalkingTimerPhase.RUNNING && !state.saving && !state.saved, modifier = Modifier.fillMaxWidth()) {
                            Text(when { state.saving -> "保存中…"; state.saved -> "已保存"; else -> "保存经行" })
                        }
                        state.message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                    }
                }
            }
            item { Text("练习要点", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold) }
            item { InfoCard("站、走、停、转都不离正念", "到尽头先站稳，再以几个自然小步转身；走神后重新知道身体正在走。") }
            item { InfoCard("速度以清楚稳定为准", "昏沉可适当加快并挺直；焦躁时稳定脚掌落地感；不要把动作做得僵硬。") }
            item { InfoCard("与安般念衔接", "经行以身体行走为主，坐下后重新回到自然的入息与出息，不强迫脚步配合呼吸。") }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("最近记录", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    if (selectedIds.isNotEmpty()) TextButton(onClick = { confirmDelete = true }) { Text("删除(${selectedIds.size})") }
                }
                Text("仅保留本周记录，周一自动清除；也可勾选单条或多条删除。", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (state.history.isEmpty()) {
                item { Text("还没有经行记录。", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(state.history, key = { it.id }, contentType = { "walk_hist" }) { history ->
                    Card {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Checkbox(
                                checked = history.id in selectedIds,
                                onCheckedChange = { checked -> selectedIds = if (checked) selectedIds + history.id else selectedIds - history.id }
                            )
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("${history.date} · ${history.method}", fontWeight = FontWeight.SemiBold)
                                Text("${history.durationSeconds / 60}分 ${history.durationSeconds % 60}秒")
                                if (history.observation.isNotBlank()) CollapsibleNote(label = "经行后的观察", value = history.observation, secondary = true, collapsedMaxLines = 3)
                            }
                        }
                    }
                }
            }
        }
    
    if (showNotificationPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showNotificationPermissionDialog = false },
            title = { Text("需要通知权限") },
            text = {
                Text("未开启通知权限时，无法启动经行计时。\n\n后台到时提醒需要通知权限（用于计时保活与到时提示）。引磬本身走闹钟音量。请先允许通知权限后，再开始计时。")
            },
            confirmButton = {
                Button(onClick = {
                    showNotificationPermissionDialog = false
                    runCatching {
                        context.startActivity(NotificationPermission.appNotificationSettingsIntent(context))
                    }.onFailure {
                        runCatching {
                            context.startActivity(NotificationPermission.appDetailsSettingsIntent(context))
                        }
                    }
                }) { Text("去开启通知") }
            },
            dismissButton = {
                TextButton(onClick = { showNotificationPermissionDialog = false }) { Text("取消") }
            }
        )
    }

    if (confirmDelete) {
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text("删除经行记录？") },
                text = { Text("将删除已选择的 ${selectedIds.size} 条记录，删除后无法恢复。") },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.deleteSelected(selectedIds)
                        selectedIds = emptySet()
                        confirmDelete = false
                    }) { Text("删除") }
                },
                dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("取消") } }
            )
        }
    }
}

@Composable
private fun InfoCard(title: String, text: String) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
